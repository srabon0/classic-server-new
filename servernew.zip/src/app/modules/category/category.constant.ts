export const CategorySearchableFields = ['name'];
