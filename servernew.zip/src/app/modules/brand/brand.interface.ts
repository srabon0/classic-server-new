/* eslint-disable no-unused-vars */

export type TBrand = {
  name: string;
  description?: string;
  isDeleted: boolean;
};
