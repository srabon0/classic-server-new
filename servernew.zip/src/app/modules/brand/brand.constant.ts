export const BrandSearchableFields = ['name'];
