export const productSearchableFields = ['title', 'code', 'model'];
