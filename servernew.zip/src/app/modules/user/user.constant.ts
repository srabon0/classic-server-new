export const USER_ROLE = {
  officeAdmin: 'officeAdmin',
  admin: 'admin',
} as const;
